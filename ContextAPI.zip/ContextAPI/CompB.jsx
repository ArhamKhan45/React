import React from "react";
import CompC from "./CompC";

function CompB() {
  return (
    <div>
      <h1>CompB</h1>
      <h1>Component B called by A</h1>
      <CompC />
    </div>
  );
}

export default CompB;
