import React from "react";
import CompB from "./CompB";

function CompA() {
  return (
    <div>
      <h1> I am CompA</h1>
      <CompB />
    </div>
  );
}

export default CompA;
