import React, { createContext } from "react";
import CompA from "./CompA";

const FirstName = createContext();
const LastName = createContext();
function ContextAPI() {
  return (
    <>
      <FirstName.Provider value="Arham">
        <LastName.Provider value="khan">
          <CompA />
        </LastName.Provider>
      </FirstName.Provider>
    </>
  );
}

export default ContextAPI;
export { FirstName, LastName };

// * ContextAPI
// createContext
// provider
// consumer
