import React from "react";
import { FirstName, LastName } from "./ContextAPI";

function CompC() {
  const showvar = (
    <FirstName.Consumer>
      {(power) => {
        return (
          <LastName.Consumer>
            {(last) => {
              return (
                <div>
                  my name is {power[0]} {last} and age {power[1]}
                </div>
              );
            }}
          </LastName.Consumer>
        );
      }}
    </FirstName.Consumer>
  );

  const showvar2 = (
    <LastName.Consumer>
      {(l) => {
        return (
          <FirstName.Consumer>
            {(f) => {
              return (
                <h1>
                  My name is {f} {l}
                </h1>
              );
            }}
          </FirstName.Consumer>
        );
      }}
    </LastName.Consumer>
  );

  return (
    <div>
      {showvar2}
      <h1>Component C called by B</h1>
      <h1>I am CompC</h1>
    </div>
  );
}

export default CompC;
